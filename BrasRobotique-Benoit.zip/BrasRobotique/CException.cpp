#include <iostream>
#include <assert.h>
#include <fstream>

#include "CException.h"


CException::CException()
{
}

unsigned int CException::EXCLireValeur()
{
	return 0;
}

void CException::EXCModifierValeur(unsigned int uiValeur)
{
}
